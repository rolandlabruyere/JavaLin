-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.11.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              12.21.0.7344
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Databasestructuur van voorthuiscustomersales wordt geschreven
CREATE DATABASE IF NOT EXISTS `voorthuiscustomersales` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `voorthuiscustomersales`;

-- Structuur van  tabel voorthuiscustomersales.tb100_customer wordt geschreven
CREATE TABLE IF NOT EXISTS `tb100_customer` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Postcode` varchar(6) DEFAULT NULL,
  `HouseNumber` varchar(7) DEFAULT NULL,
  `HouseNumberTvo` varchar(15) DEFAULT NULL,
  `Street` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb100_customer: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb110_address wordt geschreven
CREATE TABLE IF NOT EXISTS `tb110_address` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(70) DEFAULT NULL,
  `zipcode` varchar(6) NOT NULL DEFAULT '',
  `hsNumber` varchar(10) NOT NULL DEFAULT '',
  `hsNumTvo` varchar(10) NOT NULL DEFAULT '',
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`) USING BTREE,
  KEY `tb110_address_idx` (`ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb110_address: ~1 rows (ongeveer)
REPLACE INTO `tb110_address` (`ip`, `email`, `zipcode`, `hsNumber`, `hsNumTvo`, `Timestamp`) VALUES
	('77.173.243.36', 'roland.labruyere@gmail.com', '1831EP', '5', ' ', '2026-08-10T17:38:02.943');

-- Structuur van  tabel voorthuiscustomersales.tb200_power_trafo_config wordt geschreven
CREATE TABLE IF NOT EXISTS `tb200_power_trafo_config` (
  `ip` varchar(15) NOT NULL DEFAULT '0',
  `trafoNum` varchar(25) NOT NULL DEFAULT '0',
  `secundary` tinyint(4) NOT NULL DEFAULT 0,
  `volts` int(11) NOT NULL DEFAULT 0,
  `milliAmps` int(11) NOT NULL DEFAULT 0,
  `centerTap` tinyint(4) NOT NULL DEFAULT 0,
  `tapFiftyVolt` tinyint(4) NOT NULL DEFAULT 0,
  `filamentFiveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentSixAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentTwelveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentCenterTap` tinyint(4) NOT NULL DEFAULT 0,
  `timestamp` varchar(25) NOT NULL DEFAULT 'timestamp',
  PRIMARY KEY (`ip`,`trafoNum`) USING BTREE,
  KEY `TrafoNum` (`trafoNum`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb200_power_trafo_config: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb210_power_trafo_calcspecs wordt geschreven
CREATE TABLE IF NOT EXISTS `tb210_power_trafo_calcspecs` (
  `ip` varchar(15) NOT NULL,
  `trafonum` varchar(25) NOT NULL,
  `primaryVA` varchar(25) DEFAULT NULL,
  `primaryAmps` varchar(25) DEFAULT NULL,
  `coreArea` varchar(25) DEFAULT NULL,
  `turnsPerVolt` varchar(25) DEFAULT NULL,
  `primWireSize` varchar(25) DEFAULT NULL,
  `primaryTurns` varchar(25) DEFAULT NULL,
  `secundaryTurns` varchar(25) DEFAULT NULL,
  `fiftyVoltTapTurns` varchar(25) DEFAULT NULL,
  `secCenterTapTurns` varchar(25) DEFAULT NULL,
  `secWireSize` varchar(25) DEFAULT NULL,
  `filFiveTurns` varchar(25) DEFAULT NULL,
  `filFiveCtTurns` varchar(25) DEFAULT NULL,
  `filFiveWireSize` varchar(25) DEFAULT NULL,
  `filSixTurns` varchar(25) DEFAULT NULL,
  `filSixCtTurns` varchar(25) DEFAULT NULL,
  `filSixWireSize` varchar(25) DEFAULT NULL,
  `filTwelveTurns` varchar(25) DEFAULT NULL,
  `filTwelveCtTurns` varchar(25) DEFAULT NULL,
  `filTwelveWireSize` varchar(25) DEFAULT NULL,
  `primTurnArea` varchar(25) DEFAULT NULL,
  `secTurnArea` varchar(25) DEFAULT NULL,
  `fiveVoltTurnArea` varchar(25) DEFAULT NULL,
  `sixVoltTurnArea` varchar(25) DEFAULT NULL,
  `twelveVoltTurnArea` varchar(25) DEFAULT NULL,
  `totalTurnArea` varchar(25) DEFAULT NULL,
  `sizeEiSheets` varchar(25) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`,`trafonum`) USING BTREE,
  KEY `trafonum` (`trafonum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb210_power_trafo_calcspecs: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb300_shoppingcart wordt geschreven
CREATE TABLE IF NOT EXISTS `tb300_shoppingcart` (
  `ClientId` varchar(36) NOT NULL,
  `GotItems` tinyint(1) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`),
  KEY `tb300_shoppingcart_idx` (`ClientId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb300_shoppingcart: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb310_shoppingcartitems wordt geschreven
CREATE TABLE IF NOT EXISTS `tb310_shoppingcartitems` (
  `ClientId` varchar(36) NOT NULL,
  `OrderRow` int(11) NOT NULL DEFAULT 0,
  `Description` varchar(50) NOT NULL,
  `IndexNr` int(11) NOT NULL,
  `itemsOrdered` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `totalItemPrice` float DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`,`OrderRow`) USING BTREE,
  KEY `tb310_shoppingcartitems_idx` (`ClientId`,`OrderRow`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb310_shoppingcartitems: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb900_session_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb900_session_settings` (
  `ip` varchar(15) NOT NULL,
  `SessionActive` tinyint(1) NOT NULL DEFAULT 0,
  `Timestamp` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`),
  KEY `Index 1` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb900_session_settings: ~1 rows (ongeveer)
REPLACE INTO `tb900_session_settings` (`ip`, `SessionActive`, `Timestamp`) VALUES
	('077.173.243.036', 1, '2026-07-17 08:54:01:566');

-- Structuur van  tabel voorthuiscustomersales.tb910_temp_trafo_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb910_temp_trafo_settings` (
  `Ip` varchar(15) NOT NULL,
  `Part` int(11) NOT NULL DEFAULT 0,
  `TrafoType` varchar(50) DEFAULT NULL,
  `CommonValues` varchar(500) DEFAULT NULL,
  `TimeStamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`Part`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb910_temp_trafo_settings: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb920_customer_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb920_customer_settings` (
  `Ip` varchar(15) NOT NULL DEFAULT '',
  `PermissionStoreAddress` tinyint(4) DEFAULT NULL,
  `PermissionStorePaymentStats` tinyint(4) DEFAULT NULL,
  `AgreeShopConditions` tinyint(4) DEFAULT NULL,
  `ShowInteractiveHelp` tinyint(4) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE,
  KEY `tb920_idx` (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb920_customer_settings: ~1 rows (ongeveer)
REPLACE INTO `tb920_customer_settings` (`Ip`, `PermissionStoreAddress`, `PermissionStorePaymentStats`, `AgreeShopConditions`, `ShowInteractiveHelp`, `Timestamp`) VALUES
	('77.173.243.36', 1, 0, 1, 0, '2026-08-10T17:38:02.950');

-- Structuur van  tabel voorthuiscustomersales.tb930_grid_settings_per_ip wordt geschreven
CREATE TABLE IF NOT EXISTS `tb930_grid_settings_per_ip` (
  `Ip` varchar(15) NOT NULL DEFAULT '0',
  `VoltageElectraGrid` int(11) DEFAULT NULL,
  `FreqElectraGrid` int(11) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb930_grid_settings_per_ip: ~2 rows (ongeveer)
REPLACE INTO `tb930_grid_settings_per_ip` (`Ip`, `VoltageElectraGrid`, `FreqElectraGrid`, `Timestamp`) VALUES
	('77.173.243.36', 235, 50, '2026-08-10T17:38:02.932'),
	('localhost', 230, 50, '2026-03-01 00:00:00:000');

-- Structuur van  tabel voorthuiscustomersales.tb940_save_html_doc wordt geschreven
CREATE TABLE IF NOT EXISTS `tb940_save_html_doc` (
  `Ip` varchar(15) NOT NULL,
  `trafoNum` varchar(25) NOT NULL,
  `htmlDoc` mediumtext DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`trafoNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb940_save_html_doc: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb980_session_tracker wordt geschreven
CREATE TABLE IF NOT EXISTS `tb980_session_tracker` (
  `ipAddress` varchar(15) NOT NULL,
  `timestamp` varchar(25) NOT NULL,
  `visitedPage` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ipAddress`,`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb980_session_tracker: ~174 rows (ongeveer)
REPLACE INTO `tb980_session_tracker` (`ipAddress`, `timestamp`, `visitedPage`) VALUES
	('77.173.243.36', '2026-08-10T07:00:46.794', 'home'),
	('77.173.243.36', '2026-08-10T07:01:04.102', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:07:18.471', 'home'),
	('77.173.243.36', '2026-08-10T08:07:21.153', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:10:14.781', 'home'),
	('77.173.243.36', '2026-08-10T08:10:16.542', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:12:33.439', 'home'),
	('77.173.243.36', '2026-08-10T08:12:35.145', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:19:00.659', 'home'),
	('77.173.243.36', '2026-08-10T08:19:02.245', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:26:13.566', 'home'),
	('77.173.243.36', '2026-08-10T08:26:15.148', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:27:31.128', 'home'),
	('77.173.243.36', '2026-08-10T08:27:34.469', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:28:28.336', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:34:34.941', 'home'),
	('77.173.243.36', '2026-08-10T08:34:37.705', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:35:59.911', 'home'),
	('77.173.243.36', '2026-08-10T08:36:02.935', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:37:56.442', 'home'),
	('77.173.243.36', '2026-08-10T08:37:58.289', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:42:48.763', 'home'),
	('77.173.243.36', '2026-08-10T08:42:50.913', 'instellingen'),
	('77.173.243.36', '2026-08-10T08:45:19.213', 'home'),
	('77.173.243.36', '2026-08-10T08:45:20.705', 'voedingstrafo'),
	('77.173.243.36', '2026-08-10T08:45:23.821', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:39:44.631', 'home'),
	('77.173.243.36', '2026-08-10T09:39:48.587', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:40:01.567', 'home'),
	('77.173.243.36', '2026-08-10T09:40:03.093', 'voedingstrafo'),
	('77.173.243.36', '2026-08-10T09:40:14.976', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:42:43.245', 'voedingstrafo'),
	('77.173.243.36', '2026-08-10T09:42:45.620', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:43:59.168', 'home'),
	('77.173.243.36', '2026-08-10T09:44:00.819', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:44:57.370', 'home'),
	('77.173.243.36', '2026-08-10T09:44:59.508', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:50:35.840', 'home'),
	('77.173.243.36', '2026-08-10T09:50:37.637', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:52:52.579', 'home'),
	('77.173.243.36', '2026-08-10T09:52:53.858', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:55:30.563', 'home'),
	('77.173.243.36', '2026-08-10T09:55:33.243', 'instellingen'),
	('77.173.243.36', '2026-08-10T09:56:14.300', 'home'),
	('77.173.243.36', '2026-08-10T09:56:16.252', 'instellingen'),
	('77.173.243.36', '2026-08-10T10:10:54.910', 'home'),
	('77.173.243.36', '2026-08-10T10:10:57.162', 'instellingen'),
	('77.173.243.36', '2026-08-10T10:10:59.232', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T10:12:59.487', 'home'),
	('77.173.243.36', '2026-08-10T10:13:01.002', 'instellingen'),
	('77.173.243.36', '2026-08-10T10:13:03.031', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T10:15:14.863', 'home'),
	('77.173.243.36', '2026-08-10T10:15:16.971', 'instellingen'),
	('77.173.243.36', '2026-08-10T10:15:20.632', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T10:17:28.871', 'home'),
	('77.173.243.36', '2026-08-10T10:17:31.545', 'instellingen'),
	('77.173.243.36', '2026-08-10T10:17:38.142', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T10:18:27.917', 'instellingen'),
	('77.173.243.36', '2026-08-10T10:22:06.889', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T11:49:21.645', 'home'),
	('77.173.243.36', '2026-08-10T11:49:24.452', 'instellingen'),
	('77.173.243.36', '2026-08-10T11:49:26.459', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T11:51:57.435', 'instellingen'),
	('77.173.243.36', '2026-08-10T11:52:00.868', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T11:54:21.751', 'home'),
	('77.173.243.36', '2026-08-10T11:54:23.190', 'instellingen'),
	('77.173.243.36', '2026-08-10T11:54:25.721', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T11:57:19.618', 'home'),
	('77.173.243.36', '2026-08-10T11:57:20.615', 'instellingen'),
	('77.173.243.36', '2026-08-10T11:57:23.975', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T12:01:45.571', 'home'),
	('77.173.243.36', '2026-08-10T12:01:47.079', 'instellingen'),
	('77.173.243.36', '2026-08-10T12:01:48.541', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T12:04:24.766', 'home'),
	('77.173.243.36', '2026-08-10T12:04:26.637', 'instellingen'),
	('77.173.243.36', '2026-08-10T12:04:29.077', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T12:06:58.804', 'home'),
	('77.173.243.36', '2026-08-10T12:07:00.256', 'instellingen'),
	('77.173.243.36', '2026-08-10T12:07:02.377', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T12:08:29.468', 'instellingen'),
	('77.173.243.36', '2026-08-10T12:08:31.841', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T12:09:25.722', 'instellingen'),
	('77.173.243.36', '2026-08-10T12:09:28.288', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T12:09:36.519', 'home'),
	('77.173.243.36', '2026-08-10T12:09:40.261', 'instellingen'),
	('77.173.243.36', '2026-08-10T12:09:43.623', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T12:11:12.940', 'home'),
	('77.173.243.36', '2026-08-10T12:11:14.905', 'instellingen'),
	('77.173.243.36', '2026-08-10T12:11:22.177', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T15:34:17.147', 'home'),
	('77.173.243.36', '2026-08-10T15:34:19.686', 'instellingen'),
	('77.173.243.36', '2026-08-10T15:34:22.889', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T15:34:51.698', 'saveSettings'),
	('77.173.243.36', '2026-08-10T15:37:29.665', 'home'),
	('77.173.243.36', '2026-08-10T15:37:31.446', 'instellingen'),
	('77.173.243.36', '2026-08-10T15:37:34.454', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T15:38:00.933', 'saveSettings'),
	('77.173.243.36', '2026-08-10T15:41:31.930', 'home'),
	('77.173.243.36', '2026-08-10T15:41:33.894', 'instellingen'),
	('77.173.243.36', '2026-08-10T15:41:38.365', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T15:42:03.098', 'saveSettings'),
	('77.173.243.36', '2026-08-10T15:48:44.540', 'instellingen'),
	('77.173.243.36', '2026-08-10T15:48:47.763', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T15:49:14.436', 'saveSettings'),
	('77.173.243.36', '2026-08-10T16:46:26.574', 'home'),
	('77.173.243.36', '2026-08-10T16:46:28.595', 'instellingen'),
	('77.173.243.36', '2026-08-10T16:58:44.331', 'home'),
	('77.173.243.36', '2026-08-10T16:58:46.300', 'instellingen'),
	('77.173.243.36', '2026-08-10T16:58:48.680', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T16:59:17.994', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:01:17.070', 'home'),
	('77.173.243.36', '2026-08-10T17:01:18.837', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:01:22.055', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:01:51.332', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:02:50.702', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:02:53.785', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:03:28.916', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:14:01.280', 'voedingstrafo'),
	('77.173.243.36', '2026-08-10T17:14:03.196', 'home'),
	('77.173.243.36', '2026-08-10T17:14:05.242', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:14:07.552', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:14:36.484', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:16:30.543', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:16:32.903', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:16:55.663', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:18:00.317', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:18:02.206', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:18:26.362', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:19:57.812', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:20:00.466', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:20:23.947', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:20:40.159', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:20:59.364', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:21:30.499', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:23:55.690', 'home'),
	('77.173.243.36', '2026-08-10T17:24:01.570', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:24:07.775', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:24:30.074', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:28:14.536', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:28:17.489', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:28:41.915', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:31:24.785', 'home'),
	('77.173.243.36', '2026-08-10T17:31:26.482', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:31:28.538', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:31:50.990', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:32:11.574', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:32:37.088', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:32:56.357', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:33:20.951', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:33:28.780', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:33:48.647', 'saveSettings'),
	('77.173.243.36', '2026-08-10T17:34:22.633', 'home'),
	('77.173.243.36', '2026-08-10T17:34:24.128', 'voedingstrafo'),
	('77.173.243.36', '2026-08-10T17:34:26.731', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:34:29.149', 'zoeken'),
	('77.173.243.36', '2026-08-10T17:34:33.502', 'home'),
	('77.173.243.36', '2026-08-10T17:34:46.762', 'weetjes'),
	('77.173.243.36', '2026-08-10T17:34:49.322', 'home'),
	('77.173.243.36', '2026-08-10T17:35:21.648', 'voedingstrafo'),
	('77.173.243.36', '2026-08-10T17:35:24.713', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-10T17:35:26.613', 'smoorspoel'),
	('77.173.243.36', '2026-08-10T17:35:28.470', 'weetjes'),
	('77.173.243.36', '2026-08-10T17:35:30.955', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:35:34.115', 'zoeken'),
	('77.173.243.36', '2026-08-10T17:35:35.568', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:35:38.534', 'voedingstrafo'),
	('77.173.243.36', '2026-08-10T17:35:40.424', 'home'),
	('77.173.243.36', '2026-08-10T17:37:35.340', 'home'),
	('77.173.243.36', '2026-08-10T17:37:36.846', 'instellingen'),
	('77.173.243.36', '2026-08-10T17:37:39.454', 'wijzigInstellingen'),
	('77.173.243.36', '2026-08-10T17:38:02.911', 'saveSettings'),
	('77.173.243.36', '2026-08-11T07:58:34.350', 'home'),
	('77.173.243.36', '2026-08-11T07:58:39.296', 'voedingstrafo'),
	('77.173.243.36', '2026-08-11T07:58:41.870', 'instellingen');

-- Structuur van  tabel voorthuiscustomersales.tb990_paper_trail wordt geschreven
CREATE TABLE IF NOT EXISTS `tb990_paper_trail` (
  `Ip` varchar(15) NOT NULL,
  `itemNumber` varchar(25) NOT NULL,
  `docName` varchar(20) NOT NULL,
  `fullPath` varchar(500) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`itemNumber`,`docName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb990_paper_trail: ~0 rows (ongeveer)

-- Structuur van  view voorthuiscustomersales.vw205_power_trafo_all wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw205_power_trafo_all` (
	`ip` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`trafoNum` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`secundary` TINYINT(4) NOT NULL,
	`volts` INT(11) NOT NULL,
	`milliAmps` INT(11) NOT NULL,
	`centerTap` TINYINT(4) NOT NULL,
	`tapFiftyVolt` TINYINT(4) NOT NULL,
	`filamentFiveAmps` DECIMAL(4,2) NOT NULL,
	`filamentSixAmps` DECIMAL(4,2) NOT NULL,
	`filamentTwelveAmps` DECIMAL(4,2) NOT NULL,
	`filamentCenterTap` TINYINT(4) NOT NULL,
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL
);

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw925_customerstats` (
	`ip` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL,
	`PermissionStoreAddress` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`PermissionStorePaymentStats` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`AgreeShopConditions` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`ShowInteractiveHelp` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`email` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci',
	`zipcode` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumber` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumTvo` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`Timestamp` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci'
);

-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw205_power_trafo_all`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw205_power_trafo_all` AS SELECT a.ip, a.trafoNum, a.secundary, a.volts, a.milliAmps, a.centerTap, 
		 a.tapFiftyVolt, a.filamentFiveAmps, a.filamentSixAmps, 
		 a.filamentTwelveAmps, a.filamentCenterTap, b.VoltageElectraGrid, 
		 b.FreqElectraGrid 
FROM 
	tb200_power_trafo_config a,
	tb930_grid_settings_per_ip b
WHERE a.ip = b.ip 
;

-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw925_customerstats`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw925_customerstats` AS SELECT a.ip, 
		c.VoltageElectraGrid, 
		c.FreqElectraGrid, 
		if(b.PermissionStoreAddress = 1,"checked", "") AS PermissionStoreAddress,
		if(b.PermissionStorePaymentStats = 1, "checked", "") AS PermissionStorePaymentStats,
		if(b.AgreeShopConditions = 1, "checked", "") AS AgreeShopConditions,
		if(b.ShowInteractiveHelp = 1, "checked", "") AS ShowInteractiveHelp, 
		a.email, a.zipcode, a.hsNumber, a.hsNumTvo, a.Timestamp  
FROM tb110_address              a,
	  tb920_customer_settings    b,
	  tb930_grid_settings_per_ip c
WHERE a.ip = b.Ip
AND   a.ip = c.ip 
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
