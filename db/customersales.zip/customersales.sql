-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.11.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Databasestructuur van voorthuiscustomersales wordt geschreven
CREATE DATABASE IF NOT EXISTS `voorthuiscustomersales` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `voorthuiscustomersales`;

-- Structuur van  tabel voorthuiscustomersales.tb100_customer wordt geschreven
CREATE TABLE IF NOT EXISTS `tb100_customer` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Postcode` varchar(6) DEFAULT NULL,
  `HouseNumber` varchar(7) DEFAULT NULL,
  `HouseNumberTvo` varchar(15) DEFAULT NULL,
  `Street` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb100_customer: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb100_customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb100_customer` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb110_address wordt geschreven
CREATE TABLE IF NOT EXISTS `tb110_address` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(70) DEFAULT NULL,
  `zipcode` varchar(6) NOT NULL DEFAULT '',
  `hsNumber` varchar(10) NOT NULL DEFAULT '',
  `hsNumTvo` varchar(10) NOT NULL DEFAULT '',
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`) USING BTREE,
  KEY `tb110_address_idx` (`ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb110_address: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb110_address` DISABLE KEYS */;
REPLACE INTO `tb110_address` (`ip`, `email`, `zipcode`, `hsNumber`, `hsNumTvo`, `Timestamp`) VALUES
	('077.173.243.036', 'roland.labruyere@gmail.com', '1831EP', '5', '', '2026-04-10 11:41:16:491');
/*!40000 ALTER TABLE `tb110_address` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb200_power_trafo_config wordt geschreven
CREATE TABLE IF NOT EXISTS `tb200_power_trafo_config` (
  `ip` varchar(15) NOT NULL DEFAULT '0',
  `trafoNum` varchar(25) NOT NULL DEFAULT '0',
  `secundary` tinyint(4) NOT NULL DEFAULT 0,
  `volts` int(11) NOT NULL DEFAULT 0,
  `milliAmps` int(11) NOT NULL DEFAULT 0,
  `centerTap` tinyint(4) NOT NULL DEFAULT 0,
  `tapFiftyVolt` tinyint(4) NOT NULL DEFAULT 0,
  `filamentFiveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentSixAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentTwelveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentCenterTap` tinyint(4) NOT NULL DEFAULT 0,
  `timestamp` varchar(25) NOT NULL DEFAULT 'timestamp',
  PRIMARY KEY (`ip`,`trafoNum`) USING BTREE,
  KEY `TrafoNum` (`trafoNum`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb200_power_trafo_config: ~4 rows (ongeveer)
/*!40000 ALTER TABLE `tb200_power_trafo_config` DISABLE KEYS */;
REPLACE INTO `tb200_power_trafo_config` (`ip`, `trafoNum`, `secundary`, `volts`, `milliAmps`, `centerTap`, `tapFiftyVolt`, `filamentFiveAmps`, `filamentSixAmps`, `filamentTwelveAmps`, `filamentCenterTap`, `timestamp`) VALUES
	('77.173.243.36', '20260700001', 1, 400, 200, 0, 0, 3.00, 2.00, 0.00, 1, '2026-07-23T09:24:38.672'),
	('77.173.243.36', '20260700002', 1, 400, 200, 1, 0, 4.00, 3.00, 0.00, 1, '2026-07-23T09:25:15.621'),
	('77.173.243.36', '20260700003', 1, 400, 200, 0, 0, 3.00, 2.00, 0.00, 1, '2026-07-23T09:48:39.634'),
	('77.173.243.36', '20260700004', 1, 400, 200, 1, 0, 0.00, 2.00, 0.00, 1, '2026-07-23T09:49:47.998');
/*!40000 ALTER TABLE `tb200_power_trafo_config` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb210_power_trafo_calcspecs wordt geschreven
CREATE TABLE IF NOT EXISTS `tb210_power_trafo_calcspecs` (
  `ip` varchar(15) NOT NULL,
  `trafonum` varchar(25) NOT NULL,
  `isClosed` tinyint(4) DEFAULT NULL,
  `isOrdered` tinyint(4) DEFAULT NULL,
  `hasDownloadedSchematic` tinyint(4) DEFAULT NULL,
  `primaryVA` varchar(25) DEFAULT NULL,
  `primaryAmps` varchar(25) DEFAULT NULL,
  `coreArea` varchar(25) DEFAULT NULL,
  `turnsPerVolt` varchar(25) DEFAULT NULL,
  `primWireSize` varchar(25) DEFAULT NULL,
  `primaryTurns` varchar(25) DEFAULT NULL,
  `secundaryTurns` varchar(25) DEFAULT NULL,
  `fiftyVoltTapTurns` varchar(25) DEFAULT NULL,
  `secCenterTapTurns` varchar(25) DEFAULT NULL,
  `secWireSize` varchar(25) DEFAULT NULL,
  `filFiveTurns` varchar(25) DEFAULT NULL,
  `filFiveCtTurns` varchar(25) DEFAULT NULL,
  `filFiveWireSize` varchar(25) DEFAULT NULL,
  `filSixTurns` varchar(25) DEFAULT NULL,
  `filSixCtTurns` varchar(25) DEFAULT NULL,
  `filSixWireSize` varchar(25) DEFAULT NULL,
  `filTwelveTurns` varchar(25) DEFAULT NULL,
  `filTwelveCtTurns` varchar(25) DEFAULT NULL,
  `filTwelveWireSize` varchar(25) DEFAULT NULL,
  `primTurnArea` varchar(25) DEFAULT NULL,
  `secTurnArea` varchar(25) DEFAULT NULL,
  `fiveVoltTurnArea` varchar(25) DEFAULT NULL,
  `sixVoltTurnArea` varchar(25) DEFAULT NULL,
  `twelveVoltTurnArea` varchar(25) DEFAULT NULL,
  `totalTurnArea` varchar(25) DEFAULT NULL,
  `sizeEiSheets` varchar(25) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`,`trafonum`) USING BTREE,
  KEY `trafonum` (`trafonum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb210_power_trafo_calcspecs: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb210_power_trafo_calcspecs` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb210_power_trafo_calcspecs` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb300_shoppingcart wordt geschreven
CREATE TABLE IF NOT EXISTS `tb300_shoppingcart` (
  `ClientId` varchar(36) NOT NULL,
  `GotItems` tinyint(1) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`),
  KEY `tb300_shoppingcart_idx` (`ClientId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb300_shoppingcart: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb300_shoppingcart` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb300_shoppingcart` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb310_shoppingcartitems wordt geschreven
CREATE TABLE IF NOT EXISTS `tb310_shoppingcartitems` (
  `ClientId` varchar(36) NOT NULL,
  `OrderRow` int(11) NOT NULL DEFAULT 0,
  `Description` varchar(50) NOT NULL,
  `IndexNr` int(11) NOT NULL,
  `itemsOrdered` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `totalItemPrice` float DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`,`OrderRow`) USING BTREE,
  KEY `tb310_shoppingcartitems_idx` (`ClientId`,`OrderRow`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb310_shoppingcartitems: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb310_shoppingcartitems` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb310_shoppingcartitems` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb900_session_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb900_session_settings` (
  `ip` varchar(15) NOT NULL,
  `SessionActive` tinyint(1) NOT NULL DEFAULT 0,
  `Timestamp` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`),
  KEY `Index 1` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb900_session_settings: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb900_session_settings` DISABLE KEYS */;
REPLACE INTO `tb900_session_settings` (`ip`, `SessionActive`, `Timestamp`) VALUES
	('077.173.243.036', 1, '2026-07-17 08:54:01:566');
/*!40000 ALTER TABLE `tb900_session_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb910_temp_trafo_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb910_temp_trafo_settings` (
  `Ip` varchar(15) NOT NULL,
  `Part` int(11) NOT NULL DEFAULT 0,
  `TrafoType` varchar(50) DEFAULT NULL,
  `CommonValues` varchar(500) DEFAULT NULL,
  `TimeStamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`Part`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb910_temp_trafo_settings: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb910_temp_trafo_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb910_temp_trafo_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb920_customer_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb920_customer_settings` (
  `Ip` varchar(15) NOT NULL DEFAULT '',
  `PermissionStoreAddress` tinyint(4) DEFAULT NULL,
  `PermissionStorePaymentStats` tinyint(4) DEFAULT NULL,
  `AgreeShopConditions` tinyint(4) DEFAULT NULL,
  `ShowInteractiveHelp` tinyint(4) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE,
  KEY `tb920_idx` (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb920_customer_settings: ~1 rows (ongeveer)
/*!40000 ALTER TABLE `tb920_customer_settings` DISABLE KEYS */;
REPLACE INTO `tb920_customer_settings` (`Ip`, `PermissionStoreAddress`, `PermissionStorePaymentStats`, `AgreeShopConditions`, `ShowInteractiveHelp`, `Timestamp`) VALUES
	('077.173.243.036', 1, 1, 1, 1, '2026-04-10 11:41:16:505');
/*!40000 ALTER TABLE `tb920_customer_settings` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb930_grid_settings_per_ip wordt geschreven
CREATE TABLE IF NOT EXISTS `tb930_grid_settings_per_ip` (
  `Ip` varchar(15) NOT NULL DEFAULT '0',
  `VoltageElectraGrid` int(11) DEFAULT NULL,
  `FreqElectraGrid` int(11) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb930_grid_settings_per_ip: ~2 rows (ongeveer)
/*!40000 ALTER TABLE `tb930_grid_settings_per_ip` DISABLE KEYS */;
REPLACE INTO `tb930_grid_settings_per_ip` (`Ip`, `VoltageElectraGrid`, `FreqElectraGrid`, `Timestamp`) VALUES
	('077.173.243.036', 235, 50, '2026-04-10 11:41:16:479'),
	('localhost', 230, 50, '2026-03-01 00:00:00:000');
/*!40000 ALTER TABLE `tb930_grid_settings_per_ip` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb980_session_tracker wordt geschreven
CREATE TABLE IF NOT EXISTS `tb980_session_tracker` (
  `ipAddress` varchar(15) NOT NULL,
  `timestamp` varchar(25) NOT NULL,
  `visitedPage` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ipAddress`,`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb980_session_tracker: ~85 rows (ongeveer)
/*!40000 ALTER TABLE `tb980_session_tracker` DISABLE KEYS */;
REPLACE INTO `tb980_session_tracker` (`ipAddress`, `timestamp`, `visitedPage`) VALUES
	('77.173.243.36', '2026-07-23T08:57:47.912', 'home'),
	('77.173.243.36', '2026-07-23T08:57:49.814', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T08:58:01.737', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T08:59:20.885', 'home'),
	('77.173.243.36', '2026-07-23T08:59:22.969', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:02:45.414', 'home'),
	('77.173.243.36', '2026-07-23T09:02:50.242', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:02:57.381', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:03:08.879', 'home'),
	('77.173.243.36', '2026-07-23T09:03:18.916', 'home'),
	('77.173.243.36', '2026-07-23T09:03:20.145', 'home'),
	('77.173.243.36', '2026-07-23T09:03:24.048', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:03:50.499', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:03:59.910', 'home'),
	('77.173.243.36', '2026-07-23T09:04:55.773', 'home'),
	('77.173.243.36', '2026-07-23T09:04:57.253', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:05:03.034', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:05:10.291', 'home'),
	('77.173.243.36', '2026-07-23T09:06:10.310', 'home'),
	('77.173.243.36', '2026-07-23T09:06:11.339', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:06:16.054', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:08:38.699', 'home'),
	('77.173.243.36', '2026-07-23T09:08:40.597', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:08:42.163', 'home'),
	('77.173.243.36', '2026-07-23T09:08:44.171', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:08:46.476', 'uitgangstrafo'),
	('77.173.243.36', '2026-07-23T09:08:48.864', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:08:57.596', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:24:21.852', 'home'),
	('77.173.243.36', '2026-07-23T09:24:23.331', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:24:30.242', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:24:38.659', 'powertrafo'),
	('77.173.243.36', '2026-07-23T09:24:54.932', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:25:05.250', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:25:15.607', 'powertrafo'),
	('77.173.243.36', '2026-07-23T09:27:15.536', 'home'),
	('77.173.243.36', '2026-07-23T09:27:19.195', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:27:29.564', 'uitgangstrafo'),
	('77.173.243.36', '2026-07-23T09:27:32.180', 'smoorspoel'),
	('77.173.243.36', '2026-07-23T09:27:35.295', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:27:54.996', 'home'),
	('77.173.243.36', '2026-07-23T09:28:16.007', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:28:18.551', 'home'),
	('77.173.243.36', '2026-07-23T09:28:29.769', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:28:37.187', 'uitgangstrafo'),
	('77.173.243.36', '2026-07-23T09:28:39.454', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:29:29.678', 'uitgangstrafo'),
	('77.173.243.36', '2026-07-23T09:29:33.753', 'smoorspoel'),
	('77.173.243.36', '2026-07-23T09:29:39.956', 'weetjes'),
	('77.173.243.36', '2026-07-23T09:29:42.184', 'home'),
	('77.173.243.36', '2026-07-23T09:29:43.498', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:29:44.846', 'uitgangstrafo'),
	('77.173.243.36', '2026-07-23T09:31:10.891', 'smoorspoel'),
	('77.173.243.36', '2026-07-23T09:31:15.714', 'uitgangstrafo'),
	('77.173.243.36', '2026-07-23T09:32:07.759', 'diversen'),
	('77.173.243.36', '2026-07-23T09:32:10.093', 'weetjes'),
	('77.173.243.36', '2026-07-23T09:32:12.809', 'diversen'),
	('77.173.243.36', '2026-07-23T09:33:00.296', 'smoorspoel'),
	('77.173.243.36', '2026-07-23T09:33:03.541', 'weetjes'),
	('77.173.243.36', '2026-07-23T09:33:06.451', 'diversen'),
	('77.173.243.36', '2026-07-23T09:33:12.684', 'home'),
	('77.173.243.36', '2026-07-23T09:33:16.011', 'home'),
	('77.173.243.36', '2026-07-23T09:33:18.612', 'diversen'),
	('77.173.243.36', '2026-07-23T09:33:20.600', 'weetjes'),
	('77.173.243.36', '2026-07-23T09:34:02.036', 'zoeken'),
	('77.173.243.36', '2026-07-23T09:35:11.424', 'diversen'),
	('77.173.243.36', '2026-07-23T09:35:17.599', 'zoeken'),
	('77.173.243.36', '2026-07-23T09:36:51.242', 'home'),
	('77.173.243.36', '2026-07-23T09:36:53.714', 'instellingen'),
	('77.173.243.36', '2026-07-23T09:37:04.192', 'zoeken'),
	('77.173.243.36', '2026-07-23T09:37:16.137', 'diversen'),
	('77.173.243.36', '2026-07-23T09:37:18.260', 'weetjes'),
	('77.173.243.36', '2026-07-23T09:37:33.898', 'weetjes'),
	('77.173.243.36', '2026-07-23T09:37:37.469', 'instellingen'),
	('77.173.243.36', '2026-07-23T09:37:41.596', 'zoeken'),
	('77.173.243.36', '2026-07-23T09:37:57.248', 'diversen'),
	('77.173.243.36', '2026-07-23T09:48:26.991', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:48:31.438', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:48:39.601', 'powertrafo'),
	('77.173.243.36', '2026-07-23T09:49:35.089', 'home'),
	('77.173.243.36', '2026-07-23T09:49:36.334', 'voedingstrafo'),
	('77.173.243.36', '2026-07-23T09:49:42.300', 'powerTrafoLayout'),
	('77.173.243.36', '2026-07-23T09:49:47.966', 'powertrafo'),
	('77.173.243.36', '2026-07-23T09:51:26.983', 'home'),
	('77.173.243.36', '2026-07-23T09:51:28.722', 'voedingstrafo');
/*!40000 ALTER TABLE `tb980_session_tracker` ENABLE KEYS */;

-- Structuur van  tabel voorthuiscustomersales.tb990_paper_trail wordt geschreven
CREATE TABLE IF NOT EXISTS `tb990_paper_trail` (
  `Ip` varchar(15) NOT NULL,
  `itemNumber` varchar(25) NOT NULL,
  `docName` varchar(20) NOT NULL,
  `fullPath` varchar(500) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`itemNumber`,`docName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb990_paper_trail: ~0 rows (ongeveer)
/*!40000 ALTER TABLE `tb990_paper_trail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tb990_paper_trail` ENABLE KEYS */;

-- Structuur van  view voorthuiscustomersales.vw205_power_trafo_all wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw205_power_trafo_all` (
	`ip` VARCHAR(15) NOT NULL COLLATE 'latin1_swedish_ci',
	`trafoNum` VARCHAR(25) NOT NULL COLLATE 'latin1_swedish_ci',
	`secundary` TINYINT(4) NOT NULL,
	`volts` INT(11) NOT NULL,
	`milliAmps` INT(11) NOT NULL,
	`centerTap` TINYINT(4) NOT NULL,
	`tapFiftyVolt` TINYINT(4) NOT NULL,
	`filamentFiveAmps` DECIMAL(4,2) NOT NULL,
	`filamentSixAmps` DECIMAL(4,2) NOT NULL,
	`filamentTwelveAmps` DECIMAL(4,2) NOT NULL,
	`filamentCenterTap` TINYINT(4) NOT NULL,
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL
) ENGINE=MyISAM;

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw925_customerstats` (
	`ip` VARCHAR(15) NOT NULL COLLATE 'latin1_swedish_ci',
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL,
	`PermissionStoreAddress` TINYINT(4) NULL,
	`PermissionStorePaymentStats` TINYINT(4) NULL,
	`AgreeShopConditions` TINYINT(4) NULL,
	`ShowInteractiveHelp` TINYINT(4) NULL,
	`email` VARCHAR(70) NULL COLLATE 'latin1_swedish_ci',
	`zipcode` VARCHAR(6) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumber` VARCHAR(10) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumTvo` VARCHAR(10) NOT NULL COLLATE 'latin1_swedish_ci',
	`Timestamp` VARCHAR(25) NULL COLLATE 'latin1_swedish_ci'
) ENGINE=MyISAM;

-- Structuur van  view voorthuiscustomersales.vw205_power_trafo_all wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw205_power_trafo_all`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw205_power_trafo_all` AS SELECT a.ip, a.trafoNum, a.secundary, a.volts, a.milliAmps, a.centerTap, 
		 a.tapFiftyVolt, a.filamentFiveAmps, a.filamentSixAmps, 
		 a.filamentTwelveAmps, a.filamentCenterTap, b.VoltageElectraGrid, 
		 b.FreqElectraGrid 
FROM 
	tb200_power_trafo_config a,
	tb930_grid_settings_per_ip b
WHERE b.ip = a.ip ;

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw925_customerstats`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw925_customerstats` AS SELECT a.ip, c.VoltageElectraGrid, c.FreqElectraGrid, b.PermissionStoreAddress, 
		 b.PermissionStorePaymentStats, b.AgreeShopConditions, b.ShowInteractiveHelp, 
		 a.email, a.zipcode, a.hsNumber, a.hsNumTvo, a.Timestamp  
FROM tb110_address              a,
	  tb920_customer_settings    b,
	  tb930_grid_settings_per_ip c
WHERE a.ip = b.Ip
AND   a.ip = c.ip ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
