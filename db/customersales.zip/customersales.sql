-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server versie:                10.11.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Versie:              12.21.0.7344
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Databasestructuur van voorthuiscustomersales wordt geschreven
CREATE DATABASE IF NOT EXISTS `voorthuiscustomersales` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `voorthuiscustomersales`;

-- Structuur van  tabel voorthuiscustomersales.tb100_customer wordt geschreven
CREATE TABLE IF NOT EXISTS `tb100_customer` (
  `Id` int(11) NOT NULL,
  `FirstName` varchar(50) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `Postcode` varchar(6) DEFAULT NULL,
  `HouseNumber` varchar(7) DEFAULT NULL,
  `HouseNumberTvo` varchar(15) DEFAULT NULL,
  `Street` varchar(50) DEFAULT NULL,
  `City` varchar(50) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb100_customer: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb110_address wordt geschreven
CREATE TABLE IF NOT EXISTS `tb110_address` (
  `ip` varchar(15) NOT NULL DEFAULT '',
  `email` varchar(70) DEFAULT NULL,
  `zipcode` varchar(6) NOT NULL DEFAULT '',
  `hsNumber` varchar(10) NOT NULL DEFAULT '',
  `hsNumTvo` varchar(10) NOT NULL DEFAULT '',
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`) USING BTREE,
  KEY `tb110_address_idx` (`ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb110_address: ~1 rows (ongeveer)
REPLACE INTO `tb110_address` (`ip`, `email`, `zipcode`, `hsNumber`, `hsNumTvo`, `Timestamp`) VALUES
	('77.173.243.36', 'roland.labruyere@gmail.com', '1831EP', '5', ' ', '2026-08-11T16:56:43.056');

-- Structuur van  tabel voorthuiscustomersales.tb200_power_trafo_config wordt geschreven
CREATE TABLE IF NOT EXISTS `tb200_power_trafo_config` (
  `ip` varchar(15) NOT NULL DEFAULT '0',
  `trafoNum` varchar(25) NOT NULL DEFAULT '0',
  `secundary` tinyint(4) NOT NULL DEFAULT 0,
  `volts` int(11) NOT NULL DEFAULT 0,
  `milliAmps` int(11) NOT NULL DEFAULT 0,
  `centerTap` tinyint(4) NOT NULL DEFAULT 0,
  `tapFiftyVolt` tinyint(4) NOT NULL DEFAULT 0,
  `filamentFiveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentSixAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentTwelveAmps` decimal(4,2) NOT NULL DEFAULT 0.00,
  `filamentCenterTap` tinyint(4) NOT NULL DEFAULT 0,
  `timestamp` varchar(25) NOT NULL DEFAULT 'timestamp',
  PRIMARY KEY (`ip`,`trafoNum`) USING BTREE,
  KEY `TrafoNum` (`trafoNum`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb200_power_trafo_config: ~3 rows (ongeveer)
REPLACE INTO `tb200_power_trafo_config` (`ip`, `trafoNum`, `secundary`, `volts`, `milliAmps`, `centerTap`, `tapFiftyVolt`, `filamentFiveAmps`, `filamentSixAmps`, `filamentTwelveAmps`, `filamentCenterTap`, `timestamp`) VALUES
	('77.173.243.36', '20260800001', 1, 650, 200, 1, 0, 3.50, 3.50, 0.00, 1, '2026-08-14T13:15:48.892'),
	('77.173.243.36', '20260800002', 1, 350, 200, 0, 0, 3.50, 3.50, 0.00, 1, '2026-08-14T13:19:33.983'),
	('77.173.243.36', '20260800003', 1, 400, 200, 0, 0, 0.00, 2.00, 0.00, 1, '2026-08-14T14:17:28.519');

-- Structuur van  tabel voorthuiscustomersales.tb210_power_trafo_calcspecs wordt geschreven
CREATE TABLE IF NOT EXISTS `tb210_power_trafo_calcspecs` (
  `ip` varchar(15) NOT NULL,
  `trafonum` varchar(25) NOT NULL,
  `primaryVA` varchar(25) DEFAULT NULL,
  `primaryAmps` varchar(25) DEFAULT NULL,
  `coreArea` varchar(25) DEFAULT NULL,
  `turnsPerVolt` varchar(25) DEFAULT NULL,
  `primWireSize` varchar(25) DEFAULT NULL,
  `primaryTurns` varchar(25) DEFAULT NULL,
  `secundaryTurns` varchar(25) DEFAULT NULL,
  `fiftyVoltTapTurns` varchar(25) DEFAULT NULL,
  `secCenterTapTurns` varchar(25) DEFAULT NULL,
  `secWireSize` varchar(25) DEFAULT NULL,
  `filFiveTurns` varchar(25) DEFAULT NULL,
  `filFiveCtTurns` varchar(25) DEFAULT NULL,
  `filFiveWireSize` varchar(25) DEFAULT NULL,
  `filSixTurns` varchar(25) DEFAULT NULL,
  `filSixCtTurns` varchar(25) DEFAULT NULL,
  `filSixWireSize` varchar(25) DEFAULT NULL,
  `filTwelveTurns` varchar(25) DEFAULT NULL,
  `filTwelveCtTurns` varchar(25) DEFAULT NULL,
  `filTwelveWireSize` varchar(25) DEFAULT NULL,
  `primTurnArea` varchar(25) DEFAULT NULL,
  `secTurnArea` varchar(25) DEFAULT NULL,
  `fiveVoltTurnArea` varchar(25) DEFAULT NULL,
  `sixVoltTurnArea` varchar(25) DEFAULT NULL,
  `twelveVoltTurnArea` varchar(25) DEFAULT NULL,
  `totalTurnArea` varchar(25) DEFAULT NULL,
  `sizeEiSheets` varchar(25) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`,`trafonum`) USING BTREE,
  KEY `trafonum` (`trafonum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb210_power_trafo_calcspecs: ~3 rows (ongeveer)
REPLACE INTO `tb210_power_trafo_calcspecs` (`ip`, `trafonum`, `primaryVA`, `primaryAmps`, `coreArea`, `turnsPerVolt`, `primWireSize`, `primaryTurns`, `secundaryTurns`, `fiftyVoltTapTurns`, `secCenterTapTurns`, `secWireSize`, `filFiveTurns`, `filFiveCtTurns`, `filFiveWireSize`, `filSixTurns`, `filSixCtTurns`, `filSixWireSize`, `filTwelveTurns`, `filTwelveCtTurns`, `filTwelveWireSize`, `primTurnArea`, `secTurnArea`, `fiveVoltTurnArea`, `sixVoltTurnArea`, `twelveVoltTurnArea`, `totalTurnArea`, `sizeEiSheets`, `timestamp`) VALUES
	('77.173.243.36', '20260800001', '188', '0,80', '15,78', '3,17', '0,30', '744', '2059', '0', '1030', '0,15', '16', '8', '0,65', '20', '10', '0,65', '0', '0', '0.00', '2,68', '1,85', '0,27', '0,34', '0,00', '5,14', 'EI-84', '2026-08-14T13:15:48.943'),
	('77.173.243.36', '20260800002', '122', '0,52', '12,69', '3,94', '0,25', '926', '1379', '0', '0', '0,15', '20', '10', '0,65', '25', '12', '0,65', '0', '0', '0.00', '2,32', '1,24', '0,33', '0,42', '0,00', '4,31', 'EI-75', '2026-08-14T13:19:34.026'),
	('77.173.243.36', '20260800003', '103', '0,44', '11,66', '4,29', '0,25', '1007', '1715', '0', '0', '0,15', '0', '0', '0.00', '27', '14', '0,50', '0', '0', '0.00', '2,52', '1,54', '0,00', '0,27', '0,00', '4,33', 'EI-75', '2026-08-14T14:17:28.571');

-- Structuur van  tabel voorthuiscustomersales.tb300_shoppingcart wordt geschreven
CREATE TABLE IF NOT EXISTS `tb300_shoppingcart` (
  `ClientId` varchar(36) NOT NULL,
  `GotItems` tinyint(1) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`),
  KEY `tb300_shoppingcart_idx` (`ClientId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb300_shoppingcart: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb310_shoppingcartitems wordt geschreven
CREATE TABLE IF NOT EXISTS `tb310_shoppingcartitems` (
  `ClientId` varchar(36) NOT NULL,
  `OrderRow` int(11) NOT NULL DEFAULT 0,
  `Description` varchar(50) NOT NULL,
  `IndexNr` int(11) NOT NULL,
  `itemsOrdered` int(11) DEFAULT NULL,
  `Price` float DEFAULT NULL,
  `totalItemPrice` float DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ClientId`,`OrderRow`) USING BTREE,
  KEY `tb310_shoppingcartitems_idx` (`ClientId`,`OrderRow`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb310_shoppingcartitems: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb900_session_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb900_session_settings` (
  `ip` varchar(15) NOT NULL,
  `SessionActive` tinyint(1) NOT NULL DEFAULT 0,
  `Timestamp` varchar(25) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`),
  KEY `Index 1` (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb900_session_settings: ~0 rows (ongeveer)
REPLACE INTO `tb900_session_settings` (`ip`, `SessionActive`, `Timestamp`) VALUES
	('077.173.243.036', 1, '2026-07-17 08:54:01:566');

-- Structuur van  tabel voorthuiscustomersales.tb910_temp_trafo_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb910_temp_trafo_settings` (
  `Ip` varchar(15) NOT NULL,
  `Part` int(11) NOT NULL DEFAULT 0,
  `TrafoType` varchar(50) DEFAULT NULL,
  `CommonValues` varchar(500) DEFAULT NULL,
  `TimeStamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`Part`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb910_temp_trafo_settings: ~0 rows (ongeveer)

-- Structuur van  tabel voorthuiscustomersales.tb920_customer_settings wordt geschreven
CREATE TABLE IF NOT EXISTS `tb920_customer_settings` (
  `Ip` varchar(15) NOT NULL DEFAULT '',
  `PermissionStoreAddress` tinyint(4) DEFAULT NULL,
  `PermissionStorePaymentStats` tinyint(4) DEFAULT NULL,
  `AgreeShopConditions` tinyint(4) DEFAULT NULL,
  `ShowInteractiveHelp` tinyint(4) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE,
  KEY `tb920_idx` (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb920_customer_settings: ~1 rows (ongeveer)
REPLACE INTO `tb920_customer_settings` (`Ip`, `PermissionStoreAddress`, `PermissionStorePaymentStats`, `AgreeShopConditions`, `ShowInteractiveHelp`, `Timestamp`) VALUES
	('77.173.243.36', 1, 1, 1, 1, '2026-08-11T16:56:43.059');

-- Structuur van  tabel voorthuiscustomersales.tb930_grid_settings_per_ip wordt geschreven
CREATE TABLE IF NOT EXISTS `tb930_grid_settings_per_ip` (
  `Ip` varchar(15) NOT NULL DEFAULT '0',
  `VoltageElectraGrid` int(11) DEFAULT NULL,
  `FreqElectraGrid` int(11) DEFAULT NULL,
  `Timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb930_grid_settings_per_ip: ~2 rows (ongeveer)
REPLACE INTO `tb930_grid_settings_per_ip` (`Ip`, `VoltageElectraGrid`, `FreqElectraGrid`, `Timestamp`) VALUES
	('77.173.243.36', 235, 50, '2026-08-11T16:56:43.048'),
	('localhost', 230, 50, '2026-03-01 00:00:00:000');

-- Structuur van  tabel voorthuiscustomersales.tb940_save_html_doc wordt geschreven
CREATE TABLE IF NOT EXISTS `tb940_save_html_doc` (
  `Ip` varchar(15) NOT NULL,
  `trafoNum` varchar(25) NOT NULL,
  `htmlDoc` mediumtext DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`trafoNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb940_save_html_doc: ~3 rows (ongeveer)
REPLACE INTO `tb940_save_html_doc` (`Ip`, `trafoNum`, `htmlDoc`, `timestamp`) VALUES
	('77.173.243.36', '20260800001', 'PGRpdj4NPHRhYmxlPg0gIDx0cj4NICAgIDx0aCBjbGFzcyA9ICJoZWFkZXIiPlZvZWRpbmdzdHJhZm8sIGJlcmVrZW5kZSBzcGVjaWZpY2F0aWVzPC90aD4NICAgIDx0aCBjbGFzcyA9ICJoZWFkZXIiPjwvdGg+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPm9yZGVybnVtbWVyIHRyYW5zZm9ybWF0b3I8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiIGlkPSJ0cmFmb0lkIj4yMDI2MDgwMDAwMTwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbnRhbCB3aWtrZWxpbmdlbiBwZXIgdm9sdDwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MywxNzwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPm9wcGVydmxhayB0cmFmb2tlcm4gKGNtPHN1cD4yPC9zdXA+KTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MTUsNzg8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5wcmltYWlyIHZlcm1vZ2VuIChWQSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjE4ODwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPnByaW1haXIgYW1wZXJhZ2UgKEEpPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDgwPC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+YWFudGFsIHByaW1haXJlIHdpa2tlbGluZ2VuPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj43NDQ8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5wcmltYWlyZSBkcmFhZGRpYW1ldGVyIChtbSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjAsMzA8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdFRpdGxlIj48L3RkPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdENlbGwiPjwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbnRhbCBzZWN1bmRhaXJlIHdpa2tlbGluZ2VuPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4yMDU5PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+c2VjdW5kYWlyZSBkcmFhZGRpYW1ldGVyIChtbSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjAsMTU8L3RkPg0gIDwvdHI+DSAgPHRyID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+bWlkZGVuYWZ0YWtraW5nIG9wIHdpa2tlbGluZzwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MTAzMDwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAic3VibWl0VGl0bGUiPjwvdGQ+DSAgICA8dGQgY2xhc3MgPSAic3VibWl0Q2VsbCI+PC90ZD4NICA8L3RyPg0gIDx0ciA+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbnRhbCA1IHZvbHQgZ2xvZWlkcmFhZHdpa2tlbGluZ2VuPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4xNjwvdGQ+DSAgPC90cj4NICA8dHIgPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj41IHZvbHQgZHJhYWRkaWFtZXRlciAobW0pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDY1PC90ZD4NICA8L3RyPg0gIDx0ciAgPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj41IHZvbHQgbWlkZGVuYWZ0YWtraW5nIG9wIHdpa2tlbGluZzwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+ODwvdGQ+DSAgPC90cj4NICA8dHIgPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5hYW50YWwgNiwzIHZvbHQgZ2xvZWlkcmFhZHdpa2tlbGluZ2VuPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4yMDwvdGQ+DSAgPC90cj4NICA8dHIgPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj42LDMgdm9sdCBkcmFhZGRpYW1ldGVyIChtbSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjAsNjU8L3RkPg0gIDwvdHI+DSAgPHRyICA+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPjYsMyB2b2x0IG1pZGRlbmFmdGFra2luZyBvcCB3aWtrZWxpbmc8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjEwPC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRUaXRsZSI+PC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRDZWxsIj48L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5wcmltYWlyZSB3aWtrZWxydWltdGUgKGNtPHN1cD4yPC9zdXA+KTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+Miw2ODwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPnNlY3VuZGFpcmUgd2lra2VscnVpbXRlIChjbTxzdXA+Mjwvc3VwPik8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjEsODU8L3RkPg0gIDwvdHI+DSAgPHRyID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+NSB2b2x0IHdpa2tlbHJ1aW10ZSAoY208c3VwPjI8L3N1cD4pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDI3PC90ZD4NICA8L3RyPg0gIDx0ciA+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPjYsMyB2b2x0IHdpa2tlbHJ1aW10ZSAoY208c3VwPjI8L3N1cD4pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDM0PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+dG90YWFsIGJlbm9kaWdkZSB3aWtrZWxydWltdGUgKGNtPHN1cD4yPC9zdXA+KTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+NSwxNDwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbmJldm9sZW4gbWFhdCB0cmFmb2JsaWs8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPkVJLTg0PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRUaXRsZSI+PC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRDZWxsIj48L3RkPg0gIDwvdHI+DTwvdGFibGU+DQ==', '2026-08-14T13:15:48.950'),
	('77.173.243.36', '20260800002', 'PGRpdj4NPHRhYmxlPg0gIDx0cj4NICAgIDx0aCBjbGFzcyA9ICJoZWFkZXIiPlZvZWRpbmdzdHJhZm8sIGJlcmVrZW5kZSBzcGVjaWZpY2F0aWVzPC90aD4NICAgIDx0aCBjbGFzcyA9ICJoZWFkZXIiPjwvdGg+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPm9yZGVybnVtbWVyIHRyYW5zZm9ybWF0b3I8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiIGlkPSJ0cmFmb0lkIj4yMDI2MDgwMDAwMjwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbnRhbCB3aWtrZWxpbmdlbiBwZXIgdm9sdDwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+Myw5NDwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPm9wcGVydmxhayB0cmFmb2tlcm4gKGNtPHN1cD4yPC9zdXA+KTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MTIsNjk8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5wcmltYWlyIHZlcm1vZ2VuIChWQSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjEyMjwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPnByaW1haXIgYW1wZXJhZ2UgKEEpPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDUyPC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+YWFudGFsIHByaW1haXJlIHdpa2tlbGluZ2VuPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj45MjY8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5wcmltYWlyZSBkcmFhZGRpYW1ldGVyIChtbSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjAsMjU8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdFRpdGxlIj48L3RkPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdENlbGwiPjwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbnRhbCBzZWN1bmRhaXJlIHdpa2tlbGluZ2VuPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4xMzc5PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+c2VjdW5kYWlyZSBkcmFhZGRpYW1ldGVyIChtbSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjAsMTU8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdFRpdGxlIj48L3RkPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdENlbGwiPjwvdGQ+DSAgPC90cj4NICA8dHIgPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5hYW50YWwgNSB2b2x0IGdsb2VpZHJhYWR3aWtrZWxpbmdlbjwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MjA8L3RkPg0gIDwvdHI+DSAgPHRyID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+NSB2b2x0IGRyYWFkZGlhbWV0ZXIgKG1tKTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MCw2NTwvdGQ+DSAgPC90cj4NICA8dHIgID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+NSB2b2x0IG1pZGRlbmFmdGFra2luZyBvcCB3aWtrZWxpbmc8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjEwPC90ZD4NICA8L3RyPg0gIDx0ciA+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbnRhbCA2LDMgdm9sdCBnbG9laWRyYWFkd2lra2VsaW5nZW48L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjI1PC90ZD4NICA8L3RyPg0gIDx0ciA+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPjYsMyB2b2x0IGRyYWFkZGlhbWV0ZXIgKG1tKTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MCw2NTwvdGQ+DSAgPC90cj4NICA8dHIgID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+NiwzIHZvbHQgbWlkZGVuYWZ0YWtraW5nIG9wIHdpa2tlbGluZzwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MTI8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdFRpdGxlIj48L3RkPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdENlbGwiPjwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPnByaW1haXJlIHdpa2tlbHJ1aW10ZSAoY208c3VwPjI8L3N1cD4pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4yLDMyPC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+c2VjdW5kYWlyZSB3aWtrZWxydWltdGUgKGNtPHN1cD4yPC9zdXA+KTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MSwyNDwvdGQ+DSAgPC90cj4NICA8dHIgPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj41IHZvbHQgd2lra2VscnVpbXRlIChjbTxzdXA+Mjwvc3VwPik8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjAsMzM8L3RkPg0gIDwvdHI+DSAgPHRyID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+NiwzIHZvbHQgd2lra2VscnVpbXRlIChjbTxzdXA+Mjwvc3VwPik8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjAsNDI8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj50b3RhYWwgYmVub2RpZ2RlIHdpa2tlbHJ1aW10ZSAoY208c3VwPjI8L3N1cD4pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj40LDMxPC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+YWFuYmV2b2xlbiBtYWF0IHRyYWZvYmxpazwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+RUktNzU8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdFRpdGxlIj48L3RkPg0gICAgPHRkIGNsYXNzID0gInN1Ym1pdENlbGwiPjwvdGQ+DSAgPC90cj4NPC90YWJsZT4N', '2026-08-14T13:19:34.035'),
	('77.173.243.36', '20260800003', 'PGRpdj4NPHRhYmxlPg0gIDx0cj4NICAgIDx0aCBjbGFzcyA9ICJoZWFkZXIiPlZvZWRpbmdzdHJhZm8sIGJlcmVrZW5kZSBzcGVjaWZpY2F0aWVzPC90aD4NICAgIDx0aCBjbGFzcyA9ICJoZWFkZXIiPjwvdGg+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPm9yZGVybnVtbWVyIHRyYW5zZm9ybWF0b3I8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiIGlkPSJ0cmFmb0lkIj4yMDI2MDgwMDAwMzwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbnRhbCB3aWtrZWxpbmdlbiBwZXIgdm9sdDwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+NCwyOTwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPm9wcGVydmxhayB0cmFmb2tlcm4gKGNtPHN1cD4yPC9zdXA+KTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MTEsNjY8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5wcmltYWlyIHZlcm1vZ2VuIChWQSk8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjEwMzwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPnByaW1haXIgYW1wZXJhZ2UgKEEpPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDQ0PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+YWFudGFsIHByaW1haXJlIHdpa2tlbGluZ2VuPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4xMDA3PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+cHJpbWFpcmUgZHJhYWRkaWFtZXRlciAobW0pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDI1PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRUaXRsZSI+PC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRDZWxsIj48L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5hYW50YWwgc2VjdW5kYWlyZSB3aWtrZWxpbmdlbjwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+MTcxNTwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPnNlY3VuZGFpcmUgZHJhYWRkaWFtZXRlciAobW0pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDE1PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRUaXRsZSI+PC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRDZWxsIj48L3RkPg0gIDwvdHI+DSAgPHRyID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+YWFudGFsIDYsMyB2b2x0IGdsb2VpZHJhYWR3aWtrZWxpbmdlbjwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+Mjc8L3RkPg0gIDwvdHI+DSAgPHRyID4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+NiwzIHZvbHQgZHJhYWRkaWFtZXRlciAobW0pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDUwPC90ZD4NICA8L3RyPg0gIDx0ciAgPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj42LDMgdm9sdCBtaWRkZW5hZnRha2tpbmcgb3Agd2lra2VsaW5nPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4xNDwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAic3VibWl0VGl0bGUiPjwvdGQ+DSAgICA8dGQgY2xhc3MgPSAic3VibWl0Q2VsbCI+PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+cHJpbWFpcmUgd2lra2VscnVpbXRlIChjbTxzdXA+Mjwvc3VwPik8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPjIsNTI8L3RkPg0gIDwvdHI+DSAgPHRyPg0gICAgPHRkIGNsYXNzID0gInJvd1RpdGxlIj5zZWN1bmRhaXJlIHdpa2tlbHJ1aW10ZSAoY208c3VwPjI8L3N1cD4pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4xLDU0PC90ZD4NICA8L3RyPg0gIDx0ciA+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPjYsMyB2b2x0IHdpa2tlbHJ1aW10ZSAoY208c3VwPjI8L3N1cD4pPC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJjZWxsIj4wLDI3PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJyb3dUaXRsZSI+dG90YWFsIGJlbm9kaWdkZSB3aWtrZWxydWltdGUgKGNtPHN1cD4yPC9zdXA+KTwvdGQ+DSAgICA8dGQgY2xhc3MgPSAiY2VsbCI+NCwzMzwvdGQ+DSAgPC90cj4NICA8dHI+DSAgICA8dGQgY2xhc3MgPSAicm93VGl0bGUiPmFhbmJldm9sZW4gbWFhdCB0cmFmb2JsaWs8L3RkPg0gICAgPHRkIGNsYXNzID0gImNlbGwiPkVJLTc1PC90ZD4NICA8L3RyPg0gIDx0cj4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRUaXRsZSI+PC90ZD4NICAgIDx0ZCBjbGFzcyA9ICJzdWJtaXRDZWxsIj48L3RkPg0gIDwvdHI+DTwvdGFibGU+DQ==', '2026-08-14T14:17:28.580');

-- Structuur van  tabel voorthuiscustomersales.tb970_active_orders wordt geschreven
CREATE TABLE IF NOT EXISTS `tb970_active_orders` (
  `ip` varchar(15) NOT NULL,
  `trafoNum` varchar(15) NOT NULL,
  `ordertype` varchar(50) DEFAULT NULL,
  `isOpen` tinyint(4) DEFAULT 0,
  `dlWindSchedule` tinyint(4) DEFAULT 0,
  `dlMatList` tinyint(4) DEFAULT 0,
  `dlMaterialOrder` tinyint(4) DEFAULT 0,
  `hasTrafoOrder` tinyint(4) DEFAULT 0,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ip`,`trafoNum`),
  KEY `ordertype` (`ordertype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb970_active_orders: ~3 rows (ongeveer)
REPLACE INTO `tb970_active_orders` (`ip`, `trafoNum`, `ordertype`, `isOpen`, `dlWindSchedule`, `dlMatList`, `dlMaterialOrder`, `hasTrafoOrder`, `timestamp`) VALUES
	('77.173.243.36', '20260800001', 'PowerTrafo', 0, 0, 0, 0, 0, '2026-08-14T13:15:48.897'),
	('77.173.243.36', '20260800002', 'PowerTrafo', 0, 0, 0, 0, 0, '2026-08-14T13:19:33.985'),
	('77.173.243.36', '20260800003', 'PowerTrafo', 0, 0, 0, 0, 0, '2026-08-14T14:17:28.524');

-- Structuur van  tabel voorthuiscustomersales.tb980_session_tracker wordt geschreven
CREATE TABLE IF NOT EXISTS `tb980_session_tracker` (
  `ipAddress` varchar(15) NOT NULL,
  `timestamp` varchar(25) NOT NULL,
  `visitedPage` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ipAddress`,`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb980_session_tracker: ~227 rows (ongeveer)
REPLACE INTO `tb980_session_tracker` (`ipAddress`, `timestamp`, `visitedPage`) VALUES
	('77.173.243.36', '2026-08-14T13:15:22.974', 'home'),
	('77.173.243.36', '2026-08-14T13:15:24.638', 'voedingstrafo'),
	('77.173.243.36', '2026-08-14T13:15:33.179', 'powerTrafoLayout'),
	('77.173.243.36', '2026-08-14T13:15:48.868', 'powertrafo'),
	('77.173.243.36', '2026-08-14T13:15:53.738', 'prepareSales'),
	('77.173.243.36', '2026-08-14T13:15:58.101', 'pdfWikkelschema'),
	('77.173.243.36', '2026-08-14T13:19:06.831', 'home'),
	('77.173.243.36', '2026-08-14T13:19:08.634', 'voedingstrafo'),
	('77.173.243.36', '2026-08-14T13:19:19.618', 'powerTrafoLayout'),
	('77.173.243.36', '2026-08-14T13:19:33.964', 'powertrafo'),
	('77.173.243.36', '2026-08-14T13:19:38.476', 'prepareSales'),
	('77.173.243.36', '2026-08-14T13:19:40.385', 'pdfWikkelschema'),
	('77.173.243.36', '2026-08-14T14:17:05.632', 'home'),
	('77.173.243.36', '2026-08-14T14:17:07.376', 'voedingstrafo'),
	('77.173.243.36', '2026-08-14T14:17:15.599', 'home'),
	('77.173.243.36', '2026-08-14T14:17:17.123', 'voedingstrafo'),
	('77.173.243.36', '2026-08-14T14:17:22.433', 'powerTrafoLayout'),
	('77.173.243.36', '2026-08-14T14:17:28.503', 'powertrafo'),
	('77.173.243.36', '2026-08-14T14:17:49.308', 'prepareSales'),
	('77.173.243.36', '2026-08-14T14:17:57.685', 'weetjes'),
	('77.173.243.36', '2026-08-14T14:19:40.756', 'weetjes'),
	('77.173.243.36', '2026-08-14T14:21:28.670', 'weetjes'),
	('77.173.243.36', '2026-08-14T14:23:46.950', 'weetjes'),
	('77.173.243.36', '2026-08-15T11:57:58.104', 'home'),
	('77.173.243.36', '2026-08-15T11:58:05.737', 'home'),
	('77.173.243.36', '2026-08-15T11:58:18.497', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T11:59:23.960', 'home'),
	('77.173.243.36', '2026-08-15T11:59:26.966', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T11:59:45.008', 'home'),
	('77.173.243.36', '2026-08-15T11:59:47.379', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:01:58.855', 'home'),
	('77.173.243.36', '2026-08-15T12:02:00.900', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:04:19.507', 'home'),
	('77.173.243.36', '2026-08-15T12:04:33.448', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:07:39.364', 'home'),
	('77.173.243.36', '2026-08-15T12:07:42.495', 'cookies'),
	('77.173.243.36', '2026-08-15T12:07:45.490', 'instellingen'),
	('77.173.243.36', '2026-08-15T12:07:53.666', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:07:54.978', 'home'),
	('77.173.243.36', '2026-08-15T12:10:02.418', 'home'),
	('77.173.243.36', '2026-08-15T12:10:11.397', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:10:11.401', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:13:04.355', 'home'),
	('77.173.243.36', '2026-08-15T12:13:08.622', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:13:08.626', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:14:52.646', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:14:52.650', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:16:10.675', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:16:10.683', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:17:19.975', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:17:19.981', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:19:43.901', 'home'),
	('77.173.243.36', '2026-08-15T12:19:46.212', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:19:46.213', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:21:20.889', 'home'),
	('77.173.243.36', '2026-08-15T12:21:23.732', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:21:23.733', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:21:54.747', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:21:54.756', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:22:41.896', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:22:41.900', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:23:28.679', 'home'),
	('77.173.243.36', '2026-08-15T12:23:28.689', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:23:42.790', 'cookies'),
	('77.173.243.36', '2026-08-15T12:23:42.793', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:23:45.713', 'instellingen'),
	('77.173.243.36', '2026-08-15T12:23:45.716', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:24:01.967', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-15T12:26:18.573', 'home'),
	('77.173.243.36', '2026-08-15T12:26:20.723', 'voedingstrafo'),
	('77.173.243.36', '2026-08-15T12:26:20.725', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:11:42.242', 'home'),
	('77.173.243.36', '2026-08-16T07:11:44.326', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:11:44.330', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:12:16.288', 'cookies'),
	('77.173.243.36', '2026-08-16T07:12:16.293', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:16:48.699', 'home'),
	('77.173.243.36', '2026-08-16T07:16:50.860', 'home'),
	('77.173.243.36', '2026-08-16T07:16:53.416', 'home'),
	('77.173.243.36', '2026-08-16T07:16:55.205', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:16:55.208', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:20:32.025', 'home'),
	('77.173.243.36', '2026-08-16T07:20:34.586', 'home'),
	('77.173.243.36', '2026-08-16T07:20:37.416', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:20:37.417', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:21:43.471', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:21:43.474', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:21:45.154', 'home'),
	('77.173.243.36', '2026-08-16T07:21:45.156', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:21:47.259', 'home'),
	('77.173.243.36', '2026-08-16T07:21:49.151', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:23:36.422', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:23:36.428', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:24:19.950', 'home'),
	('77.173.243.36', '2026-08-16T07:24:19.959', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:24:31.992', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:24:35.947', 'openstaandeOrders'),
	('77.173.243.36', '2026-08-16T07:24:39.052', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:29:40.249', 'home'),
	('77.173.243.36', '2026-08-16T07:29:42.981', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:30:33.375', 'home'),
	('77.173.243.36', '2026-08-16T07:30:34.763', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:30:34.765', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:31:05.580', 'home'),
	('77.173.243.36', '2026-08-16T07:31:12.790', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:31:12.798', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:31:26.431', 'home'),
	('77.173.243.36', '2026-08-16T07:31:28.546', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T07:31:32.248', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:31:49.844', 'home'),
	('77.173.243.36', '2026-08-16T07:31:52.604', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:33:50.849', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:33:50.855', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:34:06.137', 'home'),
	('77.173.243.36', '2026-08-16T07:34:09.635', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:34:09.637', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:34:12.058', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T07:35:08.409', 'home'),
	('77.173.243.36', '2026-08-16T07:40:12.179', 'home'),
	('77.173.243.36', '2026-08-16T07:40:14.346', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T07:40:14.347', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T07:40:21.243', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:40:21.245', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:40:24.605', 'home'),
	('77.173.243.36', '2026-08-16T07:43:41.381', 'home'),
	('77.173.243.36', '2026-08-16T07:43:44.648', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T07:43:44.649', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T07:43:47.800', 'diversen'),
	('77.173.243.36', '2026-08-16T08:13:40.930', 'home'),
	('77.173.243.36', '2026-08-16T08:13:43.783', 'home'),
	('77.173.243.36', '2026-08-16T08:14:52.181', 'home'),
	('77.173.243.36', '2026-08-16T08:14:54.181', 'home'),
	('77.173.243.36', '2026-08-16T08:14:57.109', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:14:57.112', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:15:04.136', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:15:07.300', 'smoorspoel'),
	('77.173.243.36', '2026-08-16T08:18:12.228', 'home'),
	('77.173.243.36', '2026-08-16T08:18:14.038', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:18:14.040', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:18:17.138', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T08:18:17.140', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:18:20.589', 'smoorspoel'),
	('77.173.243.36', '2026-08-16T08:18:27.884', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T08:18:27.885', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:19:58.561', 'smoorspoel'),
	('77.173.243.36', '2026-08-16T08:19:59.675', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:20:01.594', 'home'),
	('77.173.243.36', '2026-08-16T08:20:03.042', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:20:03.044', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:20:04.883', 'smoorspoelHist'),
	('77.173.243.36', '2026-08-16T08:20:09.774', 'weetjes'),
	('77.173.243.36', '2026-08-16T08:26:10.497', 'weetjes'),
	('77.173.243.36', '2026-08-16T08:27:02.756', 'weetjes'),
	('77.173.243.36', '2026-08-16T08:28:27.634', 'home'),
	('77.173.243.36', '2026-08-16T08:28:29.245', 'weetjes'),
	('77.173.243.36', '2026-08-16T08:31:29.367', 'smoorspoel'),
	('77.173.243.36', '2026-08-16T08:31:29.372', 'smoorspoelHist'),
	('77.173.243.36', '2026-08-16T08:31:32.996', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T08:31:33.005', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:31:35.116', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:31:41.042', 'home'),
	('77.173.243.36', '2026-08-16T08:32:42.434', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:32:42.438', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:36:32.483', 'home'),
	('77.173.243.36', '2026-08-16T08:36:34.865', 'home'),
	('77.173.243.36', '2026-08-16T08:37:45.202', 'home'),
	('77.173.243.36', '2026-08-16T08:38:24.350', 'home'),
	('77.173.243.36', '2026-08-16T08:40:13.683', 'home'),
	('77.173.243.36', '2026-08-16T08:40:14.932', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:40:14.934', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:42:17.908', 'home'),
	('77.173.243.36', '2026-08-16T08:42:19.711', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:42:19.712', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:42:24.318', 'home'),
	('77.173.243.36', '2026-08-16T08:42:27.175', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:44:11.749', 'home'),
	('77.173.243.36', '2026-08-16T08:44:13.310', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:44:13.313', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:44:44.031', 'smoorspoel'),
	('77.173.243.36', '2026-08-16T08:44:44.039', 'smoorspoelHist'),
	('77.173.243.36', '2026-08-16T08:44:46.238', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T08:44:46.246', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:44:47.448', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:44:47.450', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:46:11.282', 'home'),
	('77.173.243.36', '2026-08-16T08:46:16.982', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:46:16.986', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:47:11.129', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T08:47:11.130', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:47:14.974', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:47:14.977', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:48:38.990', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:48:38.994', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:49:41.170', 'home'),
	('77.173.243.36', '2026-08-16T08:49:43.386', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:49:43.388', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:49:52.468', 'smoorspoelHist'),
	('77.173.243.36', '2026-08-16T08:50:37.083', 'home'),
	('77.173.243.36', '2026-08-16T08:50:42.196', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:50:42.200', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:50:50.163', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T08:50:50.167', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T08:51:27.305', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T08:51:27.314', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T08:51:30.096', 'home'),
	('77.173.243.36', '2026-08-16T08:51:33.055', 'cookies'),
	('77.173.243.36', '2026-08-16T08:51:37.046', 'instellingen'),
	('77.173.243.36', '2026-08-16T08:51:41.859', 'zoeken'),
	('77.173.243.36', '2026-08-16T08:51:46.274', 'diversen'),
	('77.173.243.36', '2026-08-16T08:51:50.690', 'weetjes'),
	('77.173.243.36', '2026-08-16T09:00:43.858', 'home'),
	('77.173.243.36', '2026-08-16T09:00:48.404', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T09:00:48.406', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T09:00:55.387', 'weetjes'),
	('77.173.243.36', '2026-08-16T09:00:58.222', 'zoeken'),
	('77.173.243.36', '2026-08-16T09:01:12.094', 'cookies'),
	('77.173.243.36', '2026-08-16T09:01:33.265', 'instellingen'),
	('77.173.243.36', '2026-08-16T09:01:37.674', 'cookies'),
	('77.173.243.36', '2026-08-16T09:01:42.616', 'instellingen'),
	('77.173.243.36', '2026-08-16T09:01:48.777', 'zoeken'),
	('77.173.243.36', '2026-08-16T09:01:53.813', 'diversen'),
	('77.173.243.36', '2026-08-16T09:01:56.694', 'weetjes'),
	('77.173.243.36', '2026-08-16T09:23:20.863', 'home'),
	('77.173.243.36', '2026-08-16T09:23:25.113', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T09:23:25.115', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T09:23:32.073', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T09:23:32.080', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T10:51:32.667', 'home'),
	('77.173.243.36', '2026-08-16T10:51:33.995', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T10:51:33.997', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T10:53:16.469', 'home'),
	('77.173.243.36', '2026-08-16T10:53:18.634', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T10:53:18.640', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T10:53:20.729', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T10:53:20.734', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T10:53:27.495', 'smoorspoel'),
	('77.173.243.36', '2026-08-16T10:53:27.499', 'smoorspoelHist'),
	('77.173.243.36', '2026-08-16T11:10:33.353', 'home'),
	('77.173.243.36', '2026-08-16T11:10:34.764', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T11:10:34.766', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T11:10:37.866', 'opgeslagenTrafo'),
	('77.173.243.36', '2026-08-16T11:10:55.001', 'opgeslagenTrafo'),
	('77.173.243.36', '2026-08-16T11:11:00.728', 'opgeslagenTrafo'),
	('77.173.243.36', '2026-08-16T11:11:13.541', 'opgeslagenTrafo'),
	('77.173.243.36', '2026-08-16T11:11:46.437', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T11:11:46.442', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T11:11:48.363', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T11:11:51.341', 'home'),
	('77.173.243.36', '2026-08-16T11:11:53.285', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T11:11:53.289', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T11:11:57.248', 'uitgangstrafo'),
	('77.173.243.36', '2026-08-16T11:11:57.251', 'uitgangstrafoHist'),
	('77.173.243.36', '2026-08-16T11:11:59.944', 'opgeslagenTrafo'),
	('77.173.243.36', '2026-08-16T11:12:10.159', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T11:12:10.168', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T11:12:14.113', 'opgeslagenTrafo'),
	('77.173.243.36', '2026-08-16T11:12:30.479', 'home'),
	('77.173.243.36', '2026-08-16T11:12:32.396', 'voedingstrafo'),
	('77.173.243.36', '2026-08-16T11:12:32.398', 'voedingstrafoHist'),
	('77.173.243.36', '2026-08-16T11:12:37.031', 'instellingen'),
	('77.173.243.36', '2026-08-16T11:12:41.506', 'cookies');

-- Structuur van  tabel voorthuiscustomersales.tb990_paper_trail wordt geschreven
CREATE TABLE IF NOT EXISTS `tb990_paper_trail` (
  `Ip` varchar(15) NOT NULL,
  `itemNumber` varchar(25) NOT NULL,
  `docName` varchar(20) NOT NULL,
  `fullPath` varchar(500) DEFAULT NULL,
  `timestamp` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`Ip`,`itemNumber`,`docName`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Dumpen data van tabel voorthuiscustomersales.tb990_paper_trail: ~0 rows (ongeveer)

-- Structuur van  view voorthuiscustomersales.vw205_power_trafo_all wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw205_power_trafo_all` (
	`ip` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`trafoNum` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`secundary` TINYINT(4) NOT NULL,
	`volts` INT(11) NOT NULL,
	`milliAmps` INT(11) NOT NULL,
	`centerTap` TINYINT(4) NOT NULL,
	`tapFiftyVolt` TINYINT(4) NOT NULL,
	`filamentFiveAmps` DECIMAL(4,2) NOT NULL,
	`filamentSixAmps` DECIMAL(4,2) NOT NULL,
	`filamentTwelveAmps` DECIMAL(4,2) NOT NULL,
	`filamentCenterTap` TINYINT(4) NOT NULL,
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL
);

-- Structuur van  view voorthuiscustomersales.vw925_customerstats wordt geschreven
-- Tijdelijke tabel wordt aangemaakt zodat we geen VIEW afhankelijkheidsfouten krijgen
CREATE TABLE `vw925_customerstats` (
	`ip` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`VoltageElectraGrid` INT(11) NULL,
	`FreqElectraGrid` INT(11) NULL,
	`PermissionStoreAddress` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`PermissionStorePaymentStats` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`AgreeShopConditions` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`ShowInteractiveHelp` VARCHAR(1) NULL COLLATE 'utf8mb4_general_ci',
	`email` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci',
	`zipcode` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumber` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`hsNumTvo` VARCHAR(1) NOT NULL COLLATE 'latin1_swedish_ci',
	`Timestamp` VARCHAR(1) NULL COLLATE 'latin1_swedish_ci'
);

-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw205_power_trafo_all`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw205_power_trafo_all` AS SELECT a.ip, a.trafoNum, a.secundary, a.volts, a.milliAmps, a.centerTap, 
		 a.tapFiftyVolt, a.filamentFiveAmps, a.filamentSixAmps, 
		 a.filamentTwelveAmps, a.filamentCenterTap, b.VoltageElectraGrid, 
		 b.FreqElectraGrid 
FROM 
	tb200_power_trafo_config a,
	tb930_grid_settings_per_ip b
WHERE a.ip = b.ip 
;

-- Tijdelijke tabel wordt verwijderd, en definitieve VIEW wordt aangemaakt.
DROP TABLE IF EXISTS `vw925_customerstats`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `vw925_customerstats` AS SELECT a.ip, 
		c.VoltageElectraGrid, 
		c.FreqElectraGrid, 
		if(b.PermissionStoreAddress = 1,"checked", "") AS PermissionStoreAddress,
		if(b.PermissionStorePaymentStats = 1, "checked", "") AS PermissionStorePaymentStats,
		if(b.AgreeShopConditions = 1, "checked", "") AS AgreeShopConditions,
		if(b.ShowInteractiveHelp = 1, "checked", "") AS ShowInteractiveHelp, 
		a.email, a.zipcode, a.hsNumber, a.hsNumTvo, a.Timestamp  
FROM tb110_address              a,
	  tb920_customer_settings    b,
	  tb930_grid_settings_per_ip c
WHERE a.ip = b.Ip
AND   a.ip = c.ip 
;

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
